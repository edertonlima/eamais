<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'edertton_eamais' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Y0MU.w}Aol&*q51b38q^F##/!egQ{ eLd0Nag %`8k&)]z`oyL;Qfr1EF)!3(8jM' );
define( 'SECURE_AUTH_KEY',  'f4W[v^a$QQA-tVDBN>5A8W(ek)7RD{PrfdVal/Qg5znzuf*uHu:I`g+m/!%3>k#b' );
define( 'LOGGED_IN_KEY',    '>Gv:P)F{^P$PY:CaO;72#~@)Y6*hFn:^ut{Jdw,kQj(`2v!u^>FVtARzTdPAib=,' );
define( 'NONCE_KEY',        'LHUmr8nEYa0 mj``N=%-_L%+r=xe:xCKwPnEc=dt`g`|c_o_$:UOz%iff+DeubZ6' );
define( 'AUTH_SALT',        'H#@12FJ)Z@JY3Use:)VTCf?S=HfEI-?a Z^Qi#u8Zh,0:re)e[{;Sp4ym&i_Z.N4' );
define( 'SECURE_AUTH_SALT', 'G>q7cqlD h^Q!@ @66=i~Xj*bbDd2Q;7{ru;|(ZHSmU-{l8Q`s7GX/OdLzW7ymqx' );
define( 'LOGGED_IN_SALT',   '7:m*bGbe,1Mt6]--SW_s#|58A_L+}9HUc,^4PzTC)Y|.d82e5+/$P_^ Kw:?03S#' );
define( 'NONCE_SALT',       '6yNrgiG1(J{B;g&+MLRtXX-?O:T8ZP,cvQj j<5J]Y9@Q@zo+OQFZat|0x*HXA?H' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
